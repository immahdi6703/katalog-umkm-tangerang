import 'package:flutter/material.dart';
import '../models/produk.dart';
import 'detail_screen.dart';
import 'keranjang_screen.dart';

class HomeScreen extends StatefulWidget {
  final String namaPengguna;
  const HomeScreen({super.key, required this.namaPengguna});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Map<Produk, int> _keranjang = {};

  String _emoji(Produk p) {
    if (p.nama.contains('Keripik')) return '🥔';
    if (p.nama.contains('Kopi')) return '☕';
    if (p.nama.contains('Tas')) return '👜';
    if (p.nama.contains('Madu')) return '🍯';
    if (p.nama.contains('Sambal')) return '🌶️';
    if (p.nama.contains('Klepon')) return '🍡';
    return '🛍️';
  }

  Future<void> _bukaDetail(Produk produk) async {
    final jumlah = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => DetailScreen(produk: produk)),
    );
    if (jumlah != null && jumlah > 0) {
      setState(() {
        _keranjang.update(produk, (v) => v + jumlah, ifAbsent: () => jumlah);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final totalItem = _keranjang.values.fold(0, (a, b) => a + b);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Katalog UMKM Tangerang'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          Stack(children: [
            IconButton(icon: const Icon(Icons.shopping_cart), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => KeranjangScreen(keranjang: _keranjang)))),
            if (totalItem > 0) Positioned(right: 8, top: 8, child: CircleAvatar(radius: 9, backgroundColor: Colors.red, child: Text('$totalItem', style: const TextStyle(fontSize: 10, color: Colors.white)))),
          ])
        ],
      ),
      body: ListView.builder(
        itemCount: daftarProduk.length,
        padding: const EdgeInsets.all(12),
        itemBuilder: (c, i) {
          final p = daftarProduk[i];
          return Card(
            elevation: 2,
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: Container(width: 55, height: 55, decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(10)), child: Center(child: Text(_emoji(p), style: const TextStyle(fontSize: 28)))),
              title: Text(p.nama, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Rp ${p.harga}', style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.w600)),
              trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              onTap: () => _bukaDetail(p),
            ),
          );
        },
      ),
    );
  }
}