import 'package:flutter/material.dart';
import '../models/produk.dart';

class DetailScreen extends StatefulWidget {
  final Produk produk;
  const DetailScreen({super.key, required this.produk});
  @override State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  int jumlah = 1;
  String _emoji(Produk p) {
    if (p.nama.contains('Keripik')) return '🥔';
    if (p.nama.contains('Kopi')) return '☕';
    if (p.nama.contains('Tas')) return '👜';
    if (p.nama.contains('Madu')) return '🍯';
    if (p.nama.contains('Sambal')) return '🌶️';
    if (p.nama.contains('Klepon')) return '🍡';
    return '🛍️';
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.produk.nama), backgroundColor: Colors.teal, foregroundColor: Colors.white),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
            Container(height: 180, decoration: BoxDecoration(color: Colors.teal.shade50, borderRadius: BorderRadius.circular(16)), child: Center(child: Text(_emoji(widget.produk), style: const TextStyle(fontSize: 80)))),
            const SizedBox(height: 20),
            Text(widget.produk.nama, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Rp ${widget.produk.harga}', style: const TextStyle(fontSize: 18, color: Colors.teal, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton.filled(onPressed: (){ if(jumlah>1) setState(()=>jumlah--); }, icon: const Icon(Icons.remove)),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Text('$jumlah', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                IconButton.filled(onPressed: (){ setState(()=>jumlah++); }, icon: const Icon(Icons.add)),
            ]),
            const Spacer(),
            SizedBox(width: double.infinity, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: () => Navigator.pop(context, jumlah), child: const Text('Tambah ke Keranjang'))),
        ]),
      ),
    );
  }
}