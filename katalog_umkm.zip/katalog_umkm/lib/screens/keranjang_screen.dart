import 'package:flutter/material.dart';
import '../models/produk.dart';

class KeranjangScreen extends StatelessWidget {
  final Map<Produk, int> keranjang;
  const KeranjangScreen({super.key, required this.keranjang});

  @override
  Widget build(BuildContext context) {
    int total = 0;
    keranjang.forEach((p, j) {
      total += p.harga * j;
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Keranjang')),
      body: Column(
        children: [
          Expanded(
            child: keranjang.isEmpty
                ? const Center(child: Text('Keranjang kosong'))
                : ListView(
                    children: keranjang.entries.map((e) {
                      return ListTile(
                        title: Text(e.key.nama),
                        trailing: Text('x${e.value}'),
                      );
                    }).toList(),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Total: Rp $total', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('Pesanan Berhasil!'),
                          content: Text('Total: Rp $total'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('OK'),
                            )
                          ],
                        ),
                      );
                    },
                    child: const Text('Checkout'),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}