import 'package:flutter/material.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _waController = TextEditingController();

  void _masuk() {
    if (_formKey.currentState!.validate()) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen(namaPengguna: _namaController.text.trim())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.storefront, size: 80),
                const SizedBox(height: 16),
                const Text('Katalog UMKM Tangerang', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 24),
                TextFormField(
                  controller: _namaController,
                  decoration: const InputDecoration(labelText: 'Nama', border: OutlineInputBorder()),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Nama wajib diisi';
                    if (v.trim().length < 3) return 'Nama minimal 3 karakter';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _waController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'No. WhatsApp', border: OutlineInputBorder(), hintText: '08xxxxxxxxxx'),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'No WA wajib diisi';
                    if (!RegExp(r'^[0-9]+$').hasMatch(v)) return 'Hanya angka';
                    if (v.length < 10 || v.length > 13) return 'Panjang 10-13 digit';
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                SizedBox(width: double.infinity, child: FilledButton(onPressed: _masuk, child: const Text('Masuk'))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}