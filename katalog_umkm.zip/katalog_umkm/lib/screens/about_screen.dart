import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tentang Aplikasi')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Katalog UMKM Tangerang v1.0', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Tugas EKT-1 Mobile Computing - Pertemuan 7'),
            const Divider(height: 32),
            const ListTile(leading: Icon(Icons.person), title: Text('Imam'), subtitle: Text('NIM: GANTI_NIM_KAMU\nKelas: GANTI_KELAS_KAMU')),
            const SizedBox(height: 16),
            const Text('Deskripsi UMKM: Aplikasi ini menampilkan 6 produk nyata dari UMKM Tangerang, meliputi makanan, minuman, dan kerajinan lokal untuk mendukung digitalisasi UMKM.'),
            const Spacer(),
            OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Kembali')),
          ],
        ),
      ),
    );
  }
}