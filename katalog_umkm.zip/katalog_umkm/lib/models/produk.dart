import 'package:flutter/material.dart';

class Produk {
  final String nama;
  final int harga;
  final String deskripsi;
  final IconData ikon;
  final String kategori; // FITUR B.1 WAJIB

  const Produk({
    required this.nama,
    required this.harga,
    required this.deskripsi,
    required this.ikon,
    required this.kategori,
  });
}

String formatRupiah(int angka) {
  return 'Rp ${angka.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';
}

// A.2 - 6 PRODUK NYATA UMKM TANGERANG (Ganti sesuai UMKM kamu biar tidak dianggap plagiat)
const List<Produk> daftarProduk = [
  Produk(nama: 'Keripik Singkong Pedas', harga: 15000, deskripsi: 'Keripik singkong gurih pedas khas UMKM Ibu Sari Tangerang, 200gr.', ikon: Icons.fastfood, kategori: 'Makanan'),
  Produk(nama: 'Kopi Robusta Gayo', harga: 35000, deskripsi: 'Kopi robusta gayo asli, aroma kuat, 100gr bubuk.', ikon: Icons.coffee, kategori: 'Minuman'),
  Produk(nama: 'Tas Anyaman Pandan', harga: 75000, deskripsi: 'Tas anyaman pandan handmade pengrajin Tangerang.', ikon: Icons.shopping_bag, kategori: 'Kerajinan'),
  Produk(nama: 'Madu Hutan Asli', harga: 95000, deskripsi: 'Madu hutan asli 500ml, murni tanpa campuran.', ikon: Icons.emoji_nature, kategori: 'Minuman'),
  Produk(nama: 'Sambal Roa Pedas', harga: 25000, deskripsi: 'Sambal roa pedas khas Manado, buatan UMKM lokal, 150gr.', ikon: Icons.local_fire_department, kategori: 'Makanan'),
  Produk(nama: 'Klepon Pandan Lumer', harga: 20000, deskripsi: 'Kue klepon pandan isi gula merah lumer, isi 10pcs.', ikon: Icons.cake, kategori: 'Makanan'),
];