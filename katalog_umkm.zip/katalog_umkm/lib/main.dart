import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/about_screen.dart';

void main() => runApp(const KatalogApp());

class KatalogApp extends StatelessWidget {
  const KatalogApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Katalog UMKM Tangerang',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true), // A.1 Ganti warna tema
      initialRoute: '/',
      routes: {'/': (context) => const LoginScreen(), '/about': (context) => const AboutScreen()},
    );
  }
}