package id.ac.kampus.katalog_umkm

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
